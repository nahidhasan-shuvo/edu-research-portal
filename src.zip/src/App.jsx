// src/App.jsx
import { useState, useEffect, useRef } from 'react'
import { Routes, Route, NavLink, Link, useLocation } from 'react-router-dom'
import {
  ArrowDownRight, ArrowRight, ArrowUpRight, BarChart3,
  Bell, Check, ChevronDown, Download, Dna, ExternalLink, Eye, FileText, FlaskConical,
  GraduationCap, Globe2, HeartPulse, Mail, MapPin, Menu,
  Orbit, Sparkles, X, Zap
} from 'lucide-react'
import { site, stats, researchAreas, projects, publications, courses, education, services } from './data/siteData'
import { notices } from './data/notices'

const iconMap = { dna: Dna, chart: BarChart3, flask: FlaskConical, leaf: HeartPulse }

// ১০টি ভিডিওর ডিরেক্ট ইউআরএল অ্যারে
const videoList = [
  "/istockphoto-1.mp4",
  "/istockphoto-2.mp4",
  "/istockphoto-3.mp4",
  "/istockphoto-4.mp4",
  "/istockphoto-5.mp4",
  "/istockphoto-6.mp4",
  "/istockphoto-7.mp4",
  "/istockphoto-8.mp4",
  "/istockphoto-9.mp4",
  "/istockphoto-10.mp4"
]

// গ্যারান্টেড হাই-কোয়ালিটি সায়েন্টিফিক ভিডিও ফলব্যাক (যদি কোনো লোকাল ফাইল মিসিং হয়)
const fallbackVideoUrl = "https://assets.mixkit.co/videos/preview/mixkit-scientist-working-in-a-laboratory-with-a-computer-42687-large.mp4"

function GlobalVideoBackground() {
  const [currentIdx, setCurrentIdx] = useState(0)
  const [activeSrc, setActiveSrc] = useState(videoList[0])
  const videoRef = useRef(null)

  // একটি ভিডিও শেষ হলে পরের ভিডিওতে যাবে
  const handleEnded = () => {
    const next = (currentIdx + 1) % videoList.length
    setCurrentIdx(next)
    setActiveSrc(videoList[next])
  }

  // যদি লোকাল ভিডিও না পায়, কালো যাতে না থাকে সেজন্য অনলাইন ভিডিও চালাবে
  const handleError = () => {
    console.warn(`Video not loaded from ${activeSrc}. Falling back to live stream.`);
    setActiveSrc(fallbackVideoUrl)
  }

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.defaultMuted = true
      videoRef.current.muted = true
      videoRef.current.load()
      const playPromise = videoRef.current.play()
      if (playPromise !== undefined) {
        playPromise.catch((err) => {
          console.log("Autoplay waiting:", err)
        })
      }
    }
  }, [activeSrc])

  return (
    <div className="global-video-universe">
      <video
        ref={videoRef}
        key={activeSrc}
        autoPlay
        muted
        playsInline
        webkit-playsinline="true"
        onEnded={handleEnded}
        onError={handleError}
        className="global-bg-video"
      >
        <source src={activeSrc} type="video/mp4" />
      </video>
      <div className="global-video-overlay" />
    </div>
  )
}

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' })
  }, [pathname])
  return null
}

function Header() {
  const [open, setOpen] = useState(false)
  const links = [
    ['Research', '/research'],
    ['Publications', '/publications'],
    ['Teaching', '/training'],
    ['Notice Board', '/notices'],
    ['Services', '/services'],
    ['About', '/about']
  ]
  return (
    <header className="header">
      <div className="nav-shell">
        <Link to="/" className="brand" onClick={() => setOpen(false)}>
          <span className="brand-mark"><Orbit size={23} strokeWidth={2.4}/></span>
          <span>
            <b>{site.name}</b>
            <small>JUST · DEPARTMENT OF MATHEMATICS</small>
          </span>
        </Link>
        <button className="menu-toggle" aria-label="Toggle menu" onClick={() => setOpen(!open)}>
          {open ? <X/> : <Menu/>}
        </button>
        <nav className={open ? 'nav-links open' : 'nav-links'}>
          {links.map(([label, href]) => (
            <NavLink key={href} to={href} onClick={() => setOpen(false)}>{label}</NavLink>
          ))}
          <a href={site.justProfileUrl} target="_blank" rel="noreferrer" className="nav-just-badge">
            JUST Faculty ↗
          </a>
          <a href={site.researchGateUrl} target="_blank" rel="noreferrer" className="nav-rg-badge">
            ResearchGate ↗
          </a>
          <Link className="nav-cta" to="/contact" onClick={() => setOpen(false)}>
            Let's Talk <ArrowUpRight size={16}/>
          </Link>
        </nav>
      </div>
    </header>
  )
}

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-top">
        <div className="footer-brand">
          <Link to="/" className="brand light">
            <span className="brand-mark"><Orbit size={23}/></span>
            <span><b>{site.name}</b><small>{site.department}</small></span>
          </Link>
          <p style={{ marginTop: '16px', color: '#9d9b93', lineHeight: '1.7' }}>
            {site.role}, {site.department}, {site.institution}.<br/>
            Investigating Data Science, Public Health Dynamics & Molecular Biochemistry.
          </p>
          <div className="footer-auth-badges">
            <a href={site.justProfileUrl} target="_blank" rel="noreferrer" className="badge-just">
              <GraduationCap size={15}/> Official JUST Faculty Profile
            </a>
            <a href={site.researchGateUrl} target="_blank" rel="noreferrer" className="badge-rg">
              <ExternalLink size={14}/> ResearchGate Profile
            </a>
          </div>
        </div>
        <div className="footer-nav">
          <span className="eyebrow">PORTFOLIO</span>
          <Link to="/research">Research Projects</Link>
          <Link to="/publications">Publications & Preprints</Link>
          <Link to="/training">Academic Courses & Modules</Link>
          <Link to="/services">Services & Mentorship</Link>
        </div>
        <div className="footer-nav">
          <span className="eyebrow">CONNECT</span>
          <Link to="/about">About Fee Faysal</Link>
          <Link to="/contact">Contact Info</Link>
          <a href={`mailto:${site.contactEmail}`}>{site.contactEmail}</a>
          <a href={site.justProfileUrl} target="_blank" rel="noreferrer">Jashore University (JUST)</a>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} {site.name}. {site.department}, {site.institution}.</span>
        <span>Data Science · Public Health · Biochemistry <Sparkles size={14}/></span>
      </div>
    </footer>
  )
}

function Eyebrow({ children, light = false }) {
  return <div className={`eyebrow ${light ? 'eyebrow-light' : ''}`}><span className="eyebrow-dot"/> {children}</div>
}

function SectionHeading({ kicker, title, text, light = false, action }) {
  return (
    <div className={`section-heading ${light ? 'light-text' : ''}`}>
      <div><Eyebrow light={light}>{kicker}</Eyebrow><h2>{title}</h2>{text && <p>{text}</p>}</div>
      {action && <Link className="text-link" to={action.to}>{action.label}<ArrowUpRight size={17}/></Link>}
    </div>
  )
}

function PageIntro({ kicker, title, description, tone = 'lime', action }) {
  return (
    <section className={`page-intro tone-${tone}`}>
      <div className="page-intro-grid">
        <div>
          <Eyebrow>{kicker}</Eyebrow>
          <h1>{title}</h1>
          <p>{description}</p>
          {action && (
            <div style={{ marginTop: '22px' }}>
              <a href={action.href} target="_blank" rel="noreferrer" className="pill-button pill-light">
                {action.label} <ExternalLink size={16}/>
              </a>
            </div>
          )}
        </div>
      </div>
      <div className="intro-bottom">
        <span>FEE FAYSAL AHMED / DATA SCIENCE, PUBLIC HEALTH & BIOCHEMISTRY</span>
        <ArrowDownRight size={21}/>
      </div>
    </section>
  )
}

function ProjectCard({ item, index = 0 }) {
  return (
    <article className={`project-card card-${item.color} reveal`} style={{ '--delay': `${index * 90}ms` }}>
      <div className="project-image">
        <img src={item.image} alt={item.title} loading="lazy"/>
        <span className="image-index">0{index + 1}</span>
        <span className="image-arrow"><ArrowUpRight/></span>
      </div>
      <div className="project-copy">
        <div className="project-meta"><span>{item.tag}</span><span>{item.year}</span></div>
        <h3>{item.title}</h3>
        <p>{item.description}</p>
        <div className="tag-row">{item.methods.map(m => <span key={m}>{m}</span>)}</div>
      </div>
    </article>
  )
}

function Home() {
  return (
    <>
      <section className="hero">
        <div className="hero-content">
          <div className="hero-kicker">
            <span className="live-dot"/> DATA SCIENCE · PUBLIC HEALTH · BIOCHEMISTRY
          </div>
          <h1>
            Data meets<br />
            <span className="word-art max-gradient-text">
              Public Health<span className="word-star">✳</span>
            </span>
            <span className="hero-period">.</span>
          </h1>

          <div className="hero-faculty-card">
            <div className="faculty-avatar-wrap">
              <img src={site.avatar} alt={site.name} />
              <span className="faculty-badge-pulse" title="Faculty Active" />
            </div>
            <div className="faculty-card-text">
              <strong>{site.name}</strong>
              <span>{site.role}</span>
              <small>{site.department}, JUST</small>
            </div>
          </div>

          <div className="hero-bottom">
            <p>{site.intro}</p>
            <Link to="/research" className="round-link" aria-label="Explore research">
              <ArrowDownRight size={28} />
            </Link>
          </div>
        </div>

        <div className="hero-footer">
          <span>{site.department} · JUST</span>
          <span>RESEARCHGATE VERIFIED RESEARCHER</span>
          <span>DATA SCIENCE, EPIDEMIOLOGY & BIOCHEMISTRY</span>
        </div>
      </section>

      <div className="just-highlight-bar">
        <span>Official Faculty Profile: Jashore University of Science & Technology</span>
        <div className="just-bar-links">
          <a href={site.justProfileUrl} target="_blank" rel="noreferrer">
            View JUST Faculty Directory <ArrowUpRight size={15} />
          </a>
          <a href={site.researchGateUrl} target="_blank" rel="noreferrer" className="rg-alt-btn">
            ResearchGate Profile <ArrowUpRight size={15} />
          </a>
        </div>
      </div>

      <section className="stats-band">
        <div className="stats-intro"><span className="mini-star">✳</span><span>SCHOLARLY<br/>PROFILE</span></div>
        {stats.map((s) => (
          <div className="stat" key={s.label}><b>{s.value}</b><span>{s.label}</span></div>
        ))}
      </section>

      <section className="section section-paper">
        <div className="container">
          <SectionHeading
            kicker="CORE SCIENTIFIC DOMAINS"
            title={<>Data Science, Public Health &<br/><em>Molecular Biochemistry.</em></>}
            text="Harnessing mathematical epidemiology, predictive biological data science, and enzyme biochemistry to solve pressing healthcare challenges."
            action={{to:'/research', label:'Explore all research'}}
          />
          <div className="research-grid">
            {researchAreas.map((a) => {
              const Icon = iconMap[a.icon] || Dna;
              return (
                <Link to="/research" className={`research-tile tile-${a.color}`} key={a.number}>
                  <div className="tile-top"><span>{a.number} / {a.category}</span><ArrowUpRight size={19}/></div>
                  <Icon className="tile-icon" size={36}/>
                  <h3>{a.title}</h3>
                  <p>{a.description}</p>
                  <div className="tile-bottom"><span>DISCOVER METHODOLOGY</span><ArrowRight size={17}/></div>
                </Link>
              )
            })}
          </div>
        </div>
      </section>

      <section className="section section-dark">
        <div className="container">
          <SectionHeading
            kicker="FEATURED INVESTIGATIONS"
            title={<>Epidemiological Models &<br/><em>Biochemical Pipelines.</em></>}
            text="Selected high-throughput molecular screening pipelines, infectious disease forecasting, and biochemical network analysis."
            light
            action={{to:'/research', label:'All projects'}}
          />
          <div className="projects-grid">
            {projects.map((p, i) => <ProjectCard item={p} index={i} key={p.id}/>)}
          </div>
        </div>
      </section>

      <section className="statement-section max-statement">
        <div className="container statement-inner">
          <div className="statement-symbol">“</div>
          <Eyebrow>ACADEMIC PHILOSOPHY</Eyebrow>
          <h2>Deciphering health data through<br/><span>mathematical & biochemical logic.</span></h2>
          <p>At Jashore University of Science and Technology, our research utilizes statistical machine learning, compartmental epidemiological models, and atomistic biochemistry to understand disease dynamics and accelerate therapeutic discoveries.</p>
          <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
            <a href={site.researchGateUrl} target="_blank" rel="noreferrer" className="pill-button">
              Explore ResearchGate Publications <ArrowUpRight size={17}/>
            </a>
            <a href={site.justProfileUrl} target="_blank" rel="noreferrer" className="pill-button pill-outline">
              JUST Faculty Profile <GraduationCap size={17}/>
            </a>
          </div>
          <div className="statement-scribble">PUBLIC<br/>HEALTH ↗</div>
        </div>
      </section>
    </>
  )
}

function Publications() {
  const [filter, setFilter] = useState('all')
  const filteredPubs = filter === 'all' ? publications : publications.filter(p => p.category === filter)

  return (
    <>
      <PageIntro
        kicker="PUBLICATIONS & OUTPUTS"
        title={<>Scholarly Articles &<br/><span>ResearchGate Repository.</span></>}
        description={`Peer-reviewed contributions in Data Science, Epidemiological Modeling, and Molecular Biochemistry authored by Fee Faysal Ahmed (${site.department}, JUST).`}
        tone="violet"
        action={{ label: "View Full ResearchGate Index", href: site.researchGateUrl }}
      />
      <section className="section section-paper">
        <div className="container">
          <div className="rg-profile-card max-card-glow">
            <div className="rg-profile-info">
              <span className="rg-badge">VERIFIED FACULTY & RESEARCHER</span>
              <h3>Fee Faysal Ahmed</h3>
              <p>
                <strong>{site.role}, {site.department}, {site.institution}</strong><br/>
                Access preprints, full-text PDFs, citation data, and collaborate on upcoming public health modeling and biochemistry studies via ResearchGate.
              </p>
            </div>
            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
              <a href={site.researchGateUrl} target="_blank" rel="noreferrer" className="rg-big-btn">
                ResearchGate Profile <ArrowUpRight size={19}/>
              </a>
              <a href={site.justProfileUrl} target="_blank" rel="noreferrer" className="just-sec-btn">
                JUST Profile <ExternalLink size={17}/>
              </a>
            </div>
          </div>

          <div className="pub-filters">
            <button className={filter === 'all' ? 'active' : ''} onClick={() => setFilter('all')}>All Works ({publications.length})</button>
            <button className={filter === 'datascience' ? 'active' : ''} onClick={() => setFilter('datascience')}>Data Science & Analytics</button>
            <button className={filter === 'publichealth' ? 'active' : ''} onClick={() => setFilter('publichealth')}>Public Health & Epidemiology</button>
            <button className={filter === 'biochem' ? 'active' : ''} onClick={() => setFilter('biochem')}>Biochemistry & Therapeutics</button>
          </div>

          <div className="publication-list">
            {filteredPubs.map((p, i) => (
              <article className="publication-row" key={`${p.title}-${i}`}>
                <div className="pub-year">{p.year}</div>
                <div className="pub-main">
                  <span className="pub-type">{p.type}</span>
                  <h3>{p.title}</h3>
                  <p>{p.authors}</p>
                  <small>{p.journal}</small>
                  <div className="pub-status">{p.status}</div>
                </div>
                <div className="pub-action">
                  <a href={p.doi} target="_blank" rel="noreferrer" title="Open on ResearchGate / Journal">
                    <ArrowUpRight/>
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}

function Research() {
  return (
    <>
      <PageIntro
        kicker="RESEARCH PORTFOLIO"
        title={<>Living Systems.<br/><span>Data & Molecular Logic.</span></>}
        description="Developing mathematical frameworks for infectious disease dynamics, high-dimensional health data science, and computational biochemistry."
      />
      <section className="section section-paper">
        <div className="container">
          <SectionHeading kicker="CORE CAPABILITIES" title={<>Analytical pipelines<br/><em>& health applications.</em></>}/>
          <div className="research-grid">
            {researchAreas.map((a) => {
              const Icon = iconMap[a.icon] || Dna;
              return (
                <article className={`research-tile tile-${a.color}`} key={a.number}>
                  <div className="tile-top"><span>{a.number} / {a.category}</span><ArrowUpRight size={19}/></div>
                  <Icon className="tile-icon" size={36}/>
                  <h3>{a.title}</h3>
                  <p>{a.description}</p>
                  <div className="tile-bottom"><span>ACTIVE DOMAIN</span><ArrowRight size={17}/></div>
                </article>
              )
            })}
          </div>
        </div>
      </section>
      <section className="section section-dark">
        <div className="container">
          <SectionHeading kicker="INVESTIGATIONS IN ACTION" title={<>Selected <em>Research Projects.</em></>} text="Disease dynamics, clinical health informatics, and phytochemical enzyme interactions." light/>
          <div className="projects-grid">{projects.map((p,i) => <ProjectCard key={p.id} item={p} index={i}/>)}</div>
        </div>
      </section>
    </>
  )
}

function Training() {
  return (
    <>
      <PageIntro
        kicker="TEACHING & WORKSHOPS"
        title={<>Data Science, Epidemiology &<br/><span>Biochemical Modeling.</span></>}
        description={`Courses conducted at ${site.institution} (${site.department}) alongside hands-on training in biological data analysis.`}
        tone="coral"
      />
      <section className="section section-paper">
        <div className="container">
          <SectionHeading kicker="COURSES & MODULES" title={<>Academic & <em>Research Modules.</em></>}/>
          <div className="course-grid">
            {courses.map((c, i) => (
              <article className={`course-card tile-${c.color}`} key={c.title}>
                <div className="course-top"><span>0{i+1}</span><span>{c.level}</span></div>
                <div className="course-icon">{i===0?<BarChart3/>:i===1?<HeartPulse/>:<Zap/>}</div>
                <h3>{c.title}</h3>
                <p>{c.description}</p>
                <div className="course-bottom">
                  <span>{c.length}</span>
                  <Link to="/contact" aria-label={`Ask about ${c.title}`}><ArrowUpRight/></Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}

function Services() {
  return (
    <>
      <PageIntro
        kicker="COLLABORATION & SERVICES"
        title={<>Data Analytics, Public Health &<br/><span>Biochemistry Consultancy.</span></>}
        description="Available for academic research collaborations, epidemiological outbreak modeling, computational enzyme docking, and joint publications."
        tone="lime"
      />
      <section className="section section-paper">
        <div className="container">
          <SectionHeading kicker="AREAS OF ENGAGEMENT" title={<>Analytical & <em>Supervisory Support.</em></>}/>
          <div className="service-list">
            {services.map((s) => (
              <article className="service-row" key={s.number}>
                <span className="service-number">{s.number}</span>
                <div><h3>{s.title}</h3><p>{s.description}</p></div>
                <span className="service-arrow"><ArrowUpRight/></span>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}

function About() {
  return (
    <>
      <PageIntro
        kicker="ACADEMIC BIOGRAPHY"
        title={<>Fee Faysal Ahmed.<br/><span>Faculty & Data Researcher.</span></>}
        description={`${site.role}, ${site.department} at ${site.institution} focusing on Data Science, Public Health Modeling, and Biochemistry.`}
        tone="violet"
      />
      <section className="section section-paper">
        <div className="container about-layout">
          <div>
            <div className="about-portrait-card">
              <img src={site.avatar} alt={site.name} />
              <div className="portrait-meta">
                <b>{site.name}</b>
                <span>{site.role}, {site.department}</span>
                <small>{site.institution}</small>
                <a href={site.justProfileUrl} target="_blank" rel="noreferrer" className="just-profile-btn">
                  Verify JUST Profile <ExternalLink size={14}/>
                </a>
              </div>
            </div>
          </div>

          <div className="about-copy">
            <Eyebrow>ACADEMIC BIOGRAPHY</Eyebrow>
            <h2>Connecting Data Science,<br/><em>Public Health & Biochemistry.</em></h2>
            <p className="about-lead">
              Fee Faysal Ahmed is a Lecturer in the Department of Mathematics at Jashore University of Science and Technology (JUST), Bangladesh.
            </p>
            <p>
              His academic and scientific pursuit revolves around mathematical epidemiology, biological data science, and molecular biochemistry. By blending statistical computation, compartmental dynamic models, and in silico enzyme characterization, he investigates community health vulnerabilities and accelerated therapeutic lead identification.
            </p>

            <div className="edu-timeline">
              <h4 style={{ margin: '25px 0 15px', fontFamily: 'Space Grotesk' }}>Academic Credentials</h4>
              {education.map((edu, idx) => (
                <div className="edu-item" key={idx}>
                  <div className="edu-year">{edu.year}</div>
                  <div className="edu-info">
                    <strong>{edu.degree}</strong>
                    <span>{edu.institution}</span>
                    <small>Focus: {edu.focus}</small>
                  </div>
                </div>
              ))}
            </div>

            <div className="principle-grid" style={{ marginTop: '30px' }}>
              <div><BarChart3/><b>Data-Driven Health</b><span>Mathematical epidemiological modeling.</span></div>
              <div><FlaskConical/><b>Biochemistry</b><span>Enzyme kinetics & in silico docking.</span></div>
              <div><Globe2/><b>Open Science</b><span>Collaborations on ResearchGate & JUST.</span></div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

function Contact() {
  const [form, setForm] = useState({ name: '', email: '', topic: 'Academic Collaboration', message: '' })
  const [copied, setCopied] = useState(false)

  function submit(e) {
    e.preventDefault()
    const subject = encodeURIComponent(`[JUST Mathematics Inquiry] ${form.topic}`)
    const body = encodeURIComponent(`Name: ${form.name}\nEmail: ${form.email}\nTopic: ${form.topic}\n\n${form.message}`)
    window.location.href = `mailto:${site.contactEmail}?subject=${subject}&body=${body}`
  }

  async function copyEmail() {
    try {
      await navigator.clipboard.writeText(site.contactEmail);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800)
    } catch {
      window.location.href = `mailto:${site.contactEmail}`
    }
  }

  return (
    <>
      <PageIntro
        kicker="CONTACT FEE FAYSAL AHMED"
        title={<>Let's collaborate on<br/><span>impactful science.</span></>}
        description="For student supervision, joint research in public health data, biochemistry modeling, or institutional inquiries."
        tone="coral"
      />
      <section className="section section-paper">
        <div className="container contact-layout">
          <div className="contact-copy">
            <Eyebrow>OFFICIAL CHANNELS</Eyebrow>
            <h2>Department of<br/><em>Mathematics.</em></h2>
            <p>You can reach me directly via official institutional email, visit the department at JUST campus, or connect on scholarly networks.</p>

            <button className="email-copy" onClick={copyEmail}>
              <Mail size={18}/><span>{site.contactEmail}</span>
              {copied ? <Check size={17}/> : <ArrowUpRight size={17}/>}
            </button>

            <div className="contact-location">
              <MapPin size={17}/>
              <span>{site.office}</span>
            </div>

            <div className="contact-location">
              <Globe2 size={17}/>
              <span>{site.location}</span>
            </div>

            <div className="social-links" style={{ marginTop: '30px' }}>
              {site.socials.map(s => (
                <a key={s.label} href={s.href} target="_blank" rel="noreferrer">
                  {s.label}<ArrowUpRight size={14}/>
                </a>
              ))}
            </div>
          </div>

          <form className="contact-form max-form" onSubmit={submit}>
            <label>Full Name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Prof./Dr./Researcher Name"/></label>
            <label>Email Address<input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="name@institution.edu"/></label>
            <label>Discussion Scope
              <span className="select-wrap">
                <select value={form.topic} onChange={e=>setForm({...form,topic:e.target.value})}>
                  <option>Academic Collaboration</option>
                  <option>Public Health & Epidemiological Data</option>
                  <option>In Silico Biochemistry & Molecular Screening</option>
                  <option>Student Supervision / Thesis</option>
                </select>
                <ChevronDown size={16}/>
              </span>
            </label>
            <label>Message<textarea required rows="5" value={form.message} onChange={e=>setForm({...form,message:e.target.value})} placeholder="Context of your research proposal or inquiry…"/></label>
            <button className="submit-button max-btn-primary" type="submit">
              Send Email via Mail Client <ArrowUpRight size={18}/>
            </button>
          </form>
        </div>
      </section>
    </>
  )
}

function NoticesPage() {
  const formatNoticeDate = (notice) => {
    const raw = notice.uploadedAt || notice.date
    if (!raw) return 'Date not provided'
    const date = new Date(raw)
    if (Number.isNaN(date.getTime())) return raw
    return new Intl.DateTimeFormat('en-GB', {
      day: '2-digit', month: 'short', year: 'numeric',
      ...(notice.uploadedAt && notice.uploadedAt.includes('T') ? { hour: '2-digit', minute: '2-digit' } : {})
    }).format(date)
  }

  return (
    <>
      <PageIntro
        kicker="OFFICIAL UPDATES & DOCUMENTS"
        title={<>Notice <span>Board.</span></>}
        description="Important notices, certificates, announcements and documents in one place."
        tone="lime"
      />
      <section className="notices-section">
        <div className="container">
          <div className="notices-heading-line">
            <div>
              <Eyebrow>NOTICE ARCHIVE</Eyebrow>
              <h2>Latest notices</h2>
            </div>
            <span className="notice-count"><Bell size={15}/>{notices.length} {notices.length === 1 ? 'notice' : 'notices'}</span>
          </div>

          {notices.length ? (
            <div className="notice-list">
              {notices.map((notice, index) => {
                const fileUrl = notice.file
                return (
                  <article className="notice-row" key={`${notice.file}-${notice.title}-${index}`}>
                    <div className="notice-file-icon" aria-hidden="true"><FileText size={19}/></div>
                    <div className="notice-main">
                      <h3 title={notice.title}>{notice.title}</h3>
                      <div className="notice-meta">
                        <span className="notice-category">{notice.category || 'Notice'}</span>
                        <span className="notice-date">{formatNoticeDate(notice)}</span>
                      </div>
                    </div>
                    <div className="notice-actions">
                      <a className="notice-action notice-view" href={fileUrl} target="_blank" rel="noreferrer" aria-label={`View ${notice.title}`}>
                        <Eye size={15}/> <span>View</span>
                      </a>
                      <a className="notice-action notice-download" href={fileUrl} download aria-label={`Download ${notice.title}`}>
                        <Download size={15}/> <span>Download</span>
                      </a>
                    </div>
                  </article>
                )
              })}
            </div>
          ) : (
            <div className="notices-empty"><Bell size={24}/><p>No notices have been published yet.</p></div>
          )}
        </div>
      </section>
    </>
  )
}

function NotFound() {
  return (
    <section className="not-found">
      <Eyebrow>404 / NOT FOUND</Eyebrow>
      <h1>Page not found.</h1>
      <Link to="/" className="pill-button">Back to home <ArrowRight size={17}/></Link>
    </section>
  )
}

export default function App() {
  return (
    <div className="app-root-shell">
      <GlobalVideoBackground />
      <ScrollToTop/>
      <Header/>
      <main className="main-content-layer">
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/research" element={<Research/>}/>
          <Route path="/publications" element={<Publications/>}/>
          <Route path="/training" element={<Training/>}/>
          <Route path="/notices" element={<NoticesPage/>}/>
          <Route path="/services" element={<Services/>}/>
          <Route path="/about" element={<About/>}/>
          <Route path="/contact" element={<Contact/>}/>
          <Route path="*" element={<NotFound/>}/>
        </Routes>
      </main>
      <Footer/>
    </div>
  )
}