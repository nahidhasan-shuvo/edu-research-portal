// Add published notices here. Place matching files in public/notices/.
// Keep each notice compact: title + date + View/Download actions.
export const notices = [
  {
    title: "Bike Notice",
    category: "Notice",
    date: "2026-10-19",
    file: "/notices/bike.jpeg",
    type: "Image",
    description: "Bike-related notice."
  }
];
